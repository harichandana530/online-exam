package com.onlineexam.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.onlineexam.dao.UserRegistrationDao;
import com.onlineexam.functions.Functions;
import com.onlineexam.model.User;
import com.onlineexam.model.UserLogin;

@Service
public class UserRegistrationServiceImpl implements UserRegistrationService {

	@Autowired
	private UserRegistrationDao dao;

	@Override
	public boolean addUser(User user) {		
		String OTP = Functions.generatePassword();
		
		System.out.println("OTP " + OTP);
		// set userLogin credentials
		UserLogin userLogin = new UserLogin(user.getUserId(), user.getEmail(), OTP);
		
		user.setUserLogin(userLogin);
//		user.getUserLogin().setEmail(user.getEmail());
		
		System.out.println(user);
		
		int isAdded = dao.addUser(user);
		System.out.println("Added " + isAdded);
		
		boolean finalStatus = false;
		boolean mailSent = false;
		if (isAdded == 1) {
//			boolean insertuserLogin = insertuserLogin(OTP, user.getEmail());
			mailSent = Functions.sendEmail(user.getEmail(), OTP);
			if (mailSent) {
				finalStatus = true;
			}
		}
		return finalStatus;
	}
//	
//	private boolean insertuserLogin(char[] OTP, String email) {
//		int insert = dao.insertPassword(OTP, email);
//		
//		if(insert == 1){
//			return true;
//		}
//		return false;
//	}

	/*public boolean updatePassword(char[] OTP, String email){
		int updated = dao.updatePassword(OTP, email);
		
		if(updated == 1){
			return true;
		}
		return false;
		
	}*/

	public UserRegistrationDao getDao() {
		return dao;
	}

	public void setDao(UserRegistrationDao dao) {
		this.dao = dao;
	}

	@Override
	public boolean updatePassword(char[] OTP, String email) {
		// TODO Auto-generated method stub
		return false;
	}

}
