package com.onlineexam.dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.onlineexam.model.User;

@Repository
public class UserRegistrationDaoImpl implements UserRegistrationDao {

	@PersistenceContext
	private EntityManager entityManager;

	public UserRegistrationDaoImpl() {
	}

	@Override
	@Transactional
	public int addUser(User user) {
		User user1 = entityManager.merge(user);
		
		
		return 1;
	}

	@Override
	public int insertPassword(char[] OTP, String email) {
		// TODO Auto-generated method stub
		return 0;
	}

//	@Override
//	@Transactional
//	public int updatePassword(char[] OTP, String email) {
//		String sql = "Update UserLogin u set u.password = :password where u.email= :email";
//		Query query = entityManager.createQuery(sql);
//		query.setParameter("password", new String(OTP));
//		query.setParameter("email", email);
//		
//		int updated = query.executeUpdate();
//		System.out.println("updated " + updated);
//		return updated;
//				
//	}

}
