package com.onlineexam.dao;

import com.onlineexam.model.User;

public interface UserRegistrationDao {
	public int addUser(User user);
	public int insertPassword(char[] OTP, String email);
}
